# Lesson 01 Starter

1. Open `index.html` in your browser.
2. You should see a heading and no console errors.
3. Use this as the base for today's examples.
